# eu.hypixel.net World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Tue, 10 Dec 2024 12:57:53 +0100` (Timestamp: `1733831873825`)
- **Captured By**: `CarsCupcake`

## Server
- **IP**: `eu.hypixel.net`
- **Capacity**: `18620/200000`
- **Brand**: `Hypixel BungeeCord (2024.12.2.1) <- Hygot 2024.12.6.1`
- **MOTD**: `                §aHypixel Network §c[1.8-1.21]    §l§c§lHOLIDAY EVENT§7  |  §e§lNEW GAME - §6§lDISASTERS!`
- **Version**: `Requires MC 1.8 / 1.21`
- **Protocol Version**: `767`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `209.222.115.23`
- **Port**: `25565`
- **Session ID**: `b1398527-cf94-4cb4-8168-2ed33f1c7d86`

This file was created by [WorldTools 1.2.6](https://github.com/Avanatiker/WorldTools/)
